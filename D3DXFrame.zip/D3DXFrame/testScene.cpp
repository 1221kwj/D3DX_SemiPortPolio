#include "stdafx.h"
#include "testScene.h"

testScene:: testScene() {}
testScene::~testScene() {}

HRESULT testScene::init()
{
	controller = new characterCtrl;

	SKINNEDMESHMANAGER->GetSkinnedMesh( "����", "./Zealot/", "zealot.x" );
	SKINNEDMESHMANAGER->GetSkinnedMesh( "����" )->SetRandomTrackPosition();
	
	OBJLOADERMANAGER->addOBJFile( "map_01", "./BG_Resource/03_Map/", "map_01.obj" );
	
	
	mapGroupList_1 = OBJLOADERMANAGER->GetGroup( "map_01" );
	
	for each ( auto iter in mapGroupList_1 )
	{
		int vSize = iter->GetPNTVerts().size();
		int mSize = iter->GetMapVertexList().size();

		for ( int i = 0; i < vSize; i++ )
		{
			iter->GetPNTVerts()[ i ].p /= 256;
			iter->GetPNTVerts()[ i ].p.z *= -1;
		}

		for ( int i = 0; i < mSize; i++ )
		{
			iter->GetMapVertexList()[ i ] /= 256;
			iter->GetMapVertexList()[ i ].z *= -1;
		}
	}
	return S_OK;
}

void testScene::release()
{
	
}

void testScene::update()
{
	for each ( auto iter in mapGroupList_1 )
	{
		controller->update( iter );
	}
	//controller->update();
	CAMERAMANAGER->update(controller->GetPosition());

	SKINNEDMESHMANAGER->GetSkinnedMesh( "����" )->SetWorldTM( *controller->GetWorldTM() );
}

void testScene::render()
{
	for each ( auto iter in mapGroupList_1 )
	{
		iter->render();
	}

	SKINNEDMESHMANAGER->GetSkinnedMesh( "����" )->UpdateAndRender();


}
