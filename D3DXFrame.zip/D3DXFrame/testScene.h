#pragma once
#include "gameNode.h"
#include "characterCtrl.h"
//class SkinnedMesh;

class testScene : public gameNode
{
public:
	testScene();
	~testScene();

	HRESULT init();
	void	release();
	void	update();
	void	render();

private:
	//SkinnedMesh * testSkin;
	vector<Group*> mapGroupList_1;
	characterCtrl* controller;
};

